def cofactor(a,i,j):
    mat=[]
    for row in a[:i]+a[i+1:]:
        cof=row[:j]+ row[j+1:]
        mat.append(cof)
    return mat

def determinant(a,order,mod):
    d=0
    if order==2:
        d=a[0][0]*a[1][1] - a[0][1]*a[1][0]
        return d %mod
    if order==3:
        for i in range(len(a)):
            for j in range(len(a[0])):
                minus=(-1)**(i+j)
                co=cofactor(a,i,j)
                adj=co[0][0]*co[1][1] - co[0][1]*co[1][0]
                d=d+ (minus * adj * a[i][j])   
            break
        return d %mod
def gcd(a,b):
    while b!=0:
        q=a//b
        r=a%b
        a=b
        b=r
    if(a==1):
        print("Gcd is equal to 1")
        return a
    else:
        print("Gcd is not equal so give the valid matrix value")
r=int(input("Enter row value :"))
c=int(input("Enter column value :"))
mat=[]

if(r!=c):
    print("Enter the same number of row and columns")
else:
    print("Correct Row and column value!!")
    for i in range (r):
        l=[]
        for j in range(c):
            print("Enter the value:",i,j)
            x=int(input())
                
            l.append(x)
        mat.append(l)
if(gcd(determinant(mat,r,26),26)==1):
    print('valid key matrix')
    print(mat)
else:
    print("Not valid")
