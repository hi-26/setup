import math

def factorize(n):
	for i in range(2,int(math.sqrt(n))+1):
		count=0
		while n%i==0:
			count+=1
			n=int(n/i)
		if count>0:
			print(i,count)
	if n>2:
		print(n,1)

n=24
factorize(n)
