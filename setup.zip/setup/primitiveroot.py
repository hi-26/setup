def primitive_root(n):
    l=[]
    temp = []
    for i in range(1,n):
        l.append(i)
    for i in l:
        for j in l:
            x=(i**j)%n
            if x in temp:
                temp = []
                break;
            temp.append(x)
        if(len(temp)==n-1):
            print(i)


a = 20
b = 50
prime = []
for i in range(a, b+1):
    flag = 0;
    for j in range(2,i):
        if(i%j==0):
            flag = 1
            break
        else:
            continue
    if flag==0:
        prime.append(i)

print("Prime numbers between 20 to 50: ", prime)
print("Primitive roots:")
for i in prime:
    print("\nprimitive root of ", i)
    primitive_root(i)